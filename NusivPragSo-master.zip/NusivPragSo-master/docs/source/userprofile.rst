User Profile
============

In this section we can edit basic information of profile and reset the password.

.. image:: userprofile.png
   :width: 500px
   :align: center
   :height: 200px


