Standard Terms
==============
 
Standard terms contains two sub modules

.. toctree::
   :maxdepth: 2

1.Medication

.. toctree::
   :maxdepth: 2

2.Other Order
