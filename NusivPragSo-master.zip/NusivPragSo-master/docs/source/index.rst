
CLINICAL TERM MAP
=================
.. image:: chs.png
    :width: 500px
    :align: center
    :height: 300px
    :alt: alternate text

.. image:: title.png
    :align: center
    :alt: alternate text
    
.. toctree::
   :maxdepth: 5
   
   whatisclinicaltermmap
   login
   ctmworkflow


Home Page
=========
.. toctree::
   :maxdepth: 5
   
   standardterms
   medication
   otherorders
   uniqueid
   synonymsmanagement
   ordersets
   reporting
   admin
   userprofile
   logout

