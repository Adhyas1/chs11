Ordersets
=========
This contains mainly two sub modules.


Zynx
^^^^
Upload Order Sets
.................
.. image:: zynxupload.png
   :width: 500px
   :align: center
   :height: 200px

Order Set
.........
Zynx Order Sets
~~~~~~~~~~~~~~~
.. image:: zynxorderset.png
   :width: 500px
   :align: center
   :height: 200px

Cerner Order Sets
~~~~~~~~~~~~~~~~~
.. image:: zynxordercos.png
   :width: 500px
   :align: center
   :height: 200px

Order Set Association
~~~~~~~~~~~~~~~~~~~~~
.. image:: zynxorderosa.png
   :width: 500px
   :align: center
   :height: 200px

Compare Order Sets
..................
.. image:: zynxcompare.png
   :width: 500px
   :align: center
   :height: 200px

Export Order Sets
.................
.. image:: zynxexport1.png
   :width: 500px
   :align:center
   :height: 200px

Provation
^^^^^^^^^

