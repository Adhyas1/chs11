ClinicalTermMap Workflow
========================
.. image:: wrk.png
    :width: 600px
    :align: center
    :height: 100px
    :alt: alternate text

.. image:: workflow.png
    :width: 600px
    :align: center
    :height: 500px
    :alt: alternate text

