

Standard Terms
==============




      

