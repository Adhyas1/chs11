
Logout
======
Click on Logout link on the right corner of the page.

.. image:: logout.png
   :width: 500px
   :align: center
   :height: 200px

