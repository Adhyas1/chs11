Medications
===========
.. image:: synonymsmedication.png
   :width: 500px
   :align: center
   :height: 200px
