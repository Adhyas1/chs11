Synonyms Management
===================
It contains mainly three sub module.

Medications
^^^^^^^^^^^
.. image:: synonymsmedications.png
   :width: 500px
   :align: center
   :height: 200px


Laboratory
^^^^^^^^^^
.. image:: synonymslaboratory.png
   :width: 500px
   :align: center
   :height: 200px


Diagnostics
^^^^^^^^^^^
.. image:: synonymsdiagnostics.png
   :width: 500px
   :align: center
   :height: 200px
